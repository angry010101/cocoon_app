package com.yakymovych.simon.yogaapp.data

data class SignInError(
        val fields: Fields,
        val message: String
)