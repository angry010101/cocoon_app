package com.yakymovych.simon.yogaapp.data.requests

data class LoginOrRegisterRequest(var email: String,var password: String)