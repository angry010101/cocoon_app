package com.yakymovych.simon.yogaapp.data.requests

data class Meta(
    val count: Int,
    val current: Int,
    val limit: Int
)