package com.yakymovych.simon.yogaapp.data

object Constants {
    val initialLoadSize = 10
    val pagedSize = 20
}