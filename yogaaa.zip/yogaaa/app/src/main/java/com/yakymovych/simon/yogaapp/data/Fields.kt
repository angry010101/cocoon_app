package com.yakymovych.simon.yogaapp.data

data class Fields(
        val email: List<String>
)