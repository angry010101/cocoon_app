package com.yakymovych.simon.yogaapp.ui

import dagger.android.support.DaggerFragment

abstract class BaseFragment : DaggerFragment() {

}