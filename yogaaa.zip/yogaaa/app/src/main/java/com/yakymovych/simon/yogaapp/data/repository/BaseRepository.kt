package com.yakymovych.simon.yogaapp.data.repository

abstract class BaseRepository {
}