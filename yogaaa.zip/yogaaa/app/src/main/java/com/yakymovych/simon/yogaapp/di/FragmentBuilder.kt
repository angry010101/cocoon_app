package com.yakymovych.simon.yogaapp.di

import dagger.Module

@Module
abstract class FragmentBuilder {

}