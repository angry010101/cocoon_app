package com.yakymovych.simon.yogaapp.data

enum class Sort {
    ID,PRIORITY,DUEBY,TITLE;

    override fun toString(): String = this.name

}