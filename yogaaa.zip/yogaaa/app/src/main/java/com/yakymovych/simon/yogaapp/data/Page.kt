package com.yakymovych.simon.yogaapp.data

import com.yakymovych.simon.yogaapp.data.requests.Meta

data class Page(var tasks: List<Task>,var meta: Meta)
